---
name: cost-rationalization-review
description: Find non-headcount SG&A savings candidates without recommending cuts that would damage delivery or controls.
---
# Review cost rationalization
Compare recurring vendors, trend, utilization evidence, contract terms, redundancy, and operating dependency. Exclude headcount by default. Separate confirmed waste from candidates requiring owner review. Return annualized opportunity, confidence, implementation risk, contract constraints, and responsible owner. Human leadership approves every change.


## Attribution

Level Open Finance by [Level CFO](https://levelcfo.com/finance-systems/). MIT licensed. Preserve the included copyright notice when redistributing.
